public class Rutina {

    public static String generarRutina(Usuario usuario) {
        String rutina = "";

        // Verificar el objetivo
        if (usuario.getObjetivo() == Usuario.Objetivo.BAJAR_DE_PESO) {
            // Si el objetivo es bajar de peso
            rutina = generarRutinaBajarDePeso(usuario);
        } else if (usuario.getObjetivo() == Usuario.Objetivo.SUBIR_DE_PESO_GANAR_MASA_MUSCULAR) {
            // Si el objetivo es subir de peso y ganar masa muscular
            rutina = generarRutinaSubirDePesoGanarMasa(usuario);
        }

        return rutina;
    }

    private static String generarRutinaBajarDePeso(Usuario usuario) {
        String rutina = "";

        // Dependiendo de la lesión y el nivel de entrenamiento, se asigna una rutina preestablecida
        switch (usuario.getLesion()) {
            case SIN_LESION:
                rutina = generarRutinaBajarDePesoSinLesion(usuario);
                break;
            case SUPERIOR:
                rutina = generarRutinaBajarDePesoConLesionSuperior(usuario);
                break;
            case INFERIOR:
                rutina = generarRutinaBajarDePesoConLesionInferior(usuario);
                break;
            default:
                rutina = "Lesión no definida.";
        }

        return rutina;
    }

    private static String generarRutinaBajarDePesoSinLesion(Usuario usuario) {
        String rutina = "";

        // Dependiendo del nivel de entrenamiento
        switch (usuario.getNivelEntrenamiento()) {
            case PRINCIPIANTE:
                rutina = "Día 1: Tren Inferior y Cardio\n" +
                        "Calentamiento (10 min): Caminata rápida o bicicleta estática (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla en máquina Smith (3x12-15, descanso 60-90 seg).\n" +
                        "Prensa de piernas (3x12-15, descanso 60-90 seg).\n" +
                        "Extensión de piernas (3x15, descanso 60 seg).\n" +
                        "Curl de piernas (3x15, descanso 60 seg).\n" +
                        "Cardio: Caminadora en intervalos (20 min alternando 2 min caminata rápida y 1 min trote).\n" +
                        "Día 2: Tren Superior y Cardio\n" +
                        "Calentamiento (10 min): Elíptica o remo (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Press de pecho en máquina (3x12-15, descanso 60-90 seg).\n" +
                        "Remo sentado en máquina (3x12-15, descanso 60 seg).\n" +
                        "Press de hombros en máquina (3x12, descanso 60-90 seg).\n" +
                        "Jalones frontales en polea (3x12-15, descanso 60 seg).\n" +
                        "Cardio: Bicicleta estática en intervalos (20 min alternando 3 min moderado y 1 min intenso).\n" +
                        "Día 3: Full Body y Cardio\n" +
                        "Calentamiento (10 min): Caminata rápida o bicicleta estática.\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto con mancuernas (3x12, descanso 60-90 seg).\n" +
                        "Zancadas asistidas (3x12 por pierna, descanso 60 seg).\n" +
                        "Press en máquina para pecho (3x15, descanso 60 seg).\n" +
                        "Remo en polea baja (3x15, descanso 60 seg).\n" +
                        "Cardio: Caminata en cinta inclinada (15 min, inclinación moderada)";
                break;
            case MEDIO:
                rutina = "Día 1: Tren Inferior y Cardio\n" +
                        "Calentamiento (10 min): Caminata rápida en caminadora con inclinación moderada.\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla con barra libre (4x8-12, descanso 60-90 seg).\n" +
                        "Peso muerto rumano con mancuernas (3x10-12, descanso 60 seg).\n" +
                        "Zancadas caminando con mancuernas (3x12 pasos por pierna, descanso 60-90 seg).\n" +
                        "Elevaciones de talones en máquina (4x15-20, descanso 45-60 seg).\n" +
                        "Cardio: HIIT en bicicleta estática (15 min alternando 30 seg al máximo y 1 min moderado).\n" +
                        "Día 2: Tren Superior y Cardio\n" +
                        "Calentamiento (10 min): Remo ergómetro o elíptica (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Press de banca con barra (4x8-10, descanso 90 seg).\n" +
                        "Dominadas asistidas (máquina o bandas) (3x6-10, descanso 60-90 seg).\n" +
                        "Press militar con barra o mancuernas (3x8-12, descanso 60 seg).\n" +
                        "Remo con mancuerna (3x10-12 por lado, descanso 60 seg).\n" +
                        "Cardio: Intervalos en cinta inclinada (20 min alternando 2 min caminata rápida en inclinación alta y 1 min trote).\n" +
                        "Día 3: Full Body y Cardio\n" +
                        "Calentamiento (10 min): Caminata en cinta o bicicleta a ritmo moderado.\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto convencional (4x8-10, descanso 90 seg).\n" +
                        "Thrusters (sentadilla con press de hombros) (3x12-15, descanso 60-90 seg).\n" +
                        "Jalones al pecho en polea (3x10-12, descanso 60 seg).\n" +
                        "Remo inclinado con barra (3x8-12, descanso 60-90 seg).\n" +
                        "Cardio: Circuito funcional (3 rondas):\n" +
                        "Cuerda de batalla (30 seg).\n" +
                        "Burpees (10 reps).\n" +
                        "Saltos al cajón (12 reps).\n" +
                        "Descanso entre rondas: 2 minutos.";
                break;
            case AVANZADO:
                rutina = "Día 1: Tren Inferior y Cardio\n" +
                        "Calentamiento (10 min): Remo ergómetro o caminadora inclinada (intensidad moderada-alta).\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla trasera con barra libre (5x6-8, descanso 90 seg).\n" +
                        "Peso muerto sumo con barra (4x8-10, descanso 90 seg).\n" +
                        "Zancadas con salto (3x15 por pierna, descanso 60 seg).\n" +
                        "Hip thrust con barra (4x10-12, descanso 60-90 seg).\n" +
                        "Cardio: HIIT en cinta o bicicleta (20 min alternando 40 seg sprint máximo y 1 min recuperación).\n" +
                        "Día 2: Tren Superior y Cardio\n" +
                        "Calentamiento (10 min): Circuito de movilidad y ejercicios dinámicos (ej.: rotaciones de hombros, jumping jacks).\n" +
                        "Ejercicios principales:\n" +
                        "Press de banca con barra (5x5-8, descanso 90 seg).\n" +
                        "Dominadas con peso o asistidas (4x6-10, descanso 90 seg).\n" +
                        "Press militar con barra o mancuernas (4x8-10, descanso 60 seg).\n" +
                        "Remo con barra (agarre pronado) (4x8-10, descanso 60-90 seg).\n" +
                        "Cardio: Circuito funcional (4 rondas):\n" +
                        "Cuerda de batalla (20 seg).\n" +
                        "Burpees con salto (12 reps).\n" +
                        "Planchas laterales (30 seg por lado).\n" +
                        "Descanso entre rondas: 2 minutos.\n" +
                        "Día 3: Full Body y Cardio\n" +
                        "Calentamiento (10 min): Movilidad y ejercicios dinámicos (sentadillas con estiramiento, swings de pierna).\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto convencional (5x5-8, descanso 90 seg).\n" +
                        "Thrusters (sentadilla con press) (4x12-15, descanso 60-90 seg).\n" +
                        "Snatch con kettlebell (3x12 por lado, descanso 60 seg).\n" +
                        "Farmer’s carry (3 rondas de 30 metros con mancuernas pesadas, descanso 90 seg).\n" +
                        "Cardio: Tabata (4 min):\n" +
                        "Ejercicio: Sprints o bicicleta.\n" +
                        "20 seg de trabajo intenso, 10 seg descanso, repetir 8 veces.";
                break;
            default:
                rutina = "Nivel de entrenamiento no definido.";
        }

        return rutina;
    }

    private static String generarRutinaBajarDePesoConLesionSuperior(Usuario usuario) {
        // Similar a la rutina anterior, pero con modificaciones para la lesión superior
        String rutina = "Día 1: Cardio + Tren Inferior\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Sentadillas en máquina Smith (3x12, descanso: 60 seg).\n" +
                "Prensa de pierna (3x12, descanso: 60 seg).\n" +
                "Elevación de talones en máquina (3x15, descanso: 60 seg).\n" +
                "Curl de piernas en máquina (3x12, descanso: 60-90 seg).\n" +
                "Cardio: Bicicleta estática o elíptica (20-30 min, opcional con intervalos).\n" +
                "Día 2: Cardio + Tren Inferior\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Sentadillas en prensa de pierna (3x12, descanso: 60 seg).\n" +
                "Stepper o máquina de escalador (15-20 min a ritmo moderado).\n" +
                "Zancadas (3x12 repeticiones por pierna, descanso: 60 seg).\n" +
                "Cardio: Caminadora a ritmo rápido o elíptica (20-30 min).\n" +
                "Día 3: Cardio + Tren Inferior (enfoque en estabilidad)\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Máquina de prensa de pierna (3x12, descanso: 60 seg).\n" +
                "Curl de piernas en máquina (3x12, descanso: 60 seg).\n" +
                "Elevación de pierna en banco plano (3x15 por pierna, descanso: 60 seg).\n";
        return rutina;
    }

    private static String generarRutinaBajarDePesoConLesionInferior(Usuario usuario) {
        // Similar a la rutina anterior, pero con modificaciones para la lesión inferior
        String rutina = "Día 1: Tren Inferior + Cardio\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Sentadillas en máquina Smith (3x12, descanso: 60-90 seg).\n" +
                "Prensa de pierna (3x12, descanso: 60-90 seg).\n" +
                "Elevación de talones en máquina (3x15, descanso: 60 seg).\n" +
                "Curl de piernas en máquina (3x12, descanso: 60-90 seg).\n" +
                "Cardio: Bicicleta estática o elíptica (20-30 min, moderado o con intervalos).\n" +
                "Día 2: Tren Inferior + Cardio\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Sentadillas en prensa de pierna (3x12, descanso: 60-90 seg).\n" +
                "Stepper o máquina de escalador (15-20 min a ritmo moderado).\n" +
                "Zancadas sin peso o con poco peso (3x12 por pierna, descanso: 60-90 seg).\n" +
                "Elevación de talones en máquina (3x15, descanso: 60 seg).\n" +
                "Cardio: Caminadora rápida o bicicleta estática (20-30 min).\n" +
                "Día 3: Tren Inferior + Cardio\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min a ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Sentadillas en máquina Smith (3x12, descanso: 60-90 seg).\n" +
                "Curl de piernas en máquina (3x12, descanso: 60-90 seg).\n" +
                "Elevación de pierna en banco plano (3x15 por pierna, descanso: 60 seg).\n" +
                "Cardio: Remos en máquina o bicicleta estática (20-30 min de intervalos alta/baja intensidad).";
        return rutina;
    }

    private static String generarRutinaSubirDePesoGanarMasa(Usuario usuario) {
        String rutina = "";

        // Dependiendo de la lesión y el nivel de entrenamiento, se asigna una rutina preestablecida
        switch (usuario.getLesion()) {
            case SIN_LESION:
                rutina = generarRutinaSubirDePesoSinLesion(usuario);
                break;
            case SUPERIOR:
                rutina = generarRutinaSubirDePesoConLesionSuperior(usuario);
                break;
            case INFERIOR:
                rutina = generarRutinaSubirDePesoConLesionInferior(usuario);
                break;
            default:
                rutina = "Lesión no definida.";
        }

        return rutina;
    }

    private static String generarRutinaSubirDePesoSinLesion(Usuario usuario) {
        String rutina = "";

        // Dependiendo del nivel de entrenamiento
        switch (usuario.getNivelEntrenamiento()) {
            case PRINCIPIANTE:
                rutina =
                        "Día 1: Tren Inferior\n" +
                        "Calentamiento (10 min): Caminata rápida o elíptica (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla en máquina Smith (3x12-15, descanso 90 seg).\n" +
                        "Prensa de piernas (3x12-15, descanso 90 seg).\n" +
                        "Curl de piernas en máquina (3x12-15, descanso 60 seg).\n" +
                        "Elevación de talones en máquina (3x15-20, descanso 60 seg).\n" +
                        "Día 2: Tren Superior\n" +
                        "Calentamiento (10 min): Elíptica o remo (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Press de pecho en máquina (3x12-15, descanso 90 seg).\n" +
                        "Jalones al pecho en polea (3x12-15, descanso 90 seg).\n" +
                        "Press de hombros en máquina (3x12-15, descanso 60-90 seg).\n" +
                        "Curl de bíceps con mancuerna (3x12, descanso 60 seg).\n" +
                        "Extensión de tríceps en polea (3x12, descanso 60 seg).\n" +
                        "Día 3: Full Body\n" +
                        "Calentamiento (10 min): Caminata rápida o bicicleta (intensidad moderada).\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto con mancuernas (3x12, descanso 90 seg).\n" +
                        "Zancadas con mancuernas (3x12 pasos por pierna, descanso 90 seg).\n" +
                        "Press de banca en máquina (3x12-15, descanso 90 seg).\n" +
                        "Remo sentado en máquina (3x12-15, descanso 90 seg).";
                break;
            case MEDIO:
                rutina = "Día 1: Tren Inferior y Abdomen\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla con barra libre (4x8-12, descanso 90 seg).\n" +
                        "Peso muerto rumano (3x10-12, descanso 90 seg).\n" +
                        "Prensa de piernas (4x10-12, descanso 90 seg).\n" +
                        "Elevación de talones de pie (4x15-20, descanso 60 seg).\n" +
                        "Crunch en máquina (3x15-20, descanso 60 seg).\n" +
                        "Día 2: Tren Superior (Push & Pull)\n" +
                        "Ejercicios principales:\n" +
                        "Press de banca con barra (4x8-10, descanso 90 seg).\n" +
                        "Dominadas asistidas o libres (4x8-10, descanso 90 seg).\n" +
                        "Press militar con barra (3x8-10, descanso 60 seg).\n" +
                        "Curl de bíceps con barra (3x10-12, descanso 60 seg).\n" +
                        "Extensión de tríceps en polea (3x10-12, descanso 60 seg).\n" +
                        "Día 3: Full Body\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto convencional (4x6-8, descanso 90 seg).\n" +
                        "Zancadas con barra o mancuernas (3x12 por pierna, descanso 90 seg).\n" +
                        "Thrusters (sentadilla con press) (3x12, descanso 90 seg).\n" +
                        "Remo con barra (3x8-12, descanso 90 seg).";
                break;
            case AVANZADO:
                rutina = "Día 1: Tren Inferior\n" +
                        "Ejercicios principales:\n" +
                        "Sentadilla trasera con barra (5x6-8, descanso 2 min).\n" +
                        "Peso muerto rumano (4x8-10, descanso 90 seg).\n" +
                        "Prensa de piernas (4x10-12, descanso 90 seg).\n" +
                        "Zancadas caminando con mancuernas (3x12 pasos por pierna, descanso 60-90 seg).\n" +
                        "Superset:\n" +
                        "Elevaciones de talones sentado (3x15-20).\n" +
                        "Elevaciones de talones de pie (3x15-20).\n" +
                        "Descanso entre supersets: 60 seg.\n" +
                        "Plancha abdominal con peso (3x30-45 seg, descanso 60 seg).\n" +
                        "Día 2: Tren Superior (Push & Pull)\n" +
                        "Ejercicios principales:\n" +
                        "Press de banca con barra (5x6-8, descanso 2 min).\n" +
                        "Dominadas lastradas o asistidas (4x8-10, descanso 90 seg).\n" +
                        "Press militar con barra (4x8-10, descanso 90 seg).\n" +
                        "Remo con barra (4x8-10, descanso 90 seg).\n" +
                        "Curl de bíceps en banco inclinado con mancuernas (3x10-12, descanso 60 seg).\n" +
                        "Extensión de tríceps por encima de la cabeza (mancuerna o barra) (3x10-12, descanso 60 seg).\n" +
                        "Día 3: Full Body\n" +
                        "Ejercicios principales:\n" +
                        "Peso muerto convencional (5x6-8, descanso 2 min).\n" +
                        "Thrusters con barra o mancuernas (4x10-12, descanso 90 seg).\n" +
                        "Remo Pendlay (4x8-10, descanso 90 seg).\n" +
                        "Bench dips lastrados (fondo en banco) (4x10-12, descanso 60-90 seg).\n" +
                        "Farmer’s carry con pesas pesadas (3 rondas de 30 m, descanso 60-90 seg).\n" +
                        "Ab wheel rollout (3x8-10, descanso 60 seg).";
                break;
            default:
                rutina = "Nivel de entrenamiento no definido.";
        }

        return rutina;
    }

    private static String generarRutinaSubirDePesoConLesionSuperior(Usuario usuario) {
        // Similar a la rutina anterior, pero con modificaciones para la lesión superior
        String rutina = "Día 1: Pecho, Espalda y Hombros\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo suave).\n" +
                "Ejercicios principales:\n" +
                "Press de banca en máquina o mancuernas (4x8-12, descanso: 90 seg).\n" +
                "Remo en máquina sentado (4x8-12, descanso: 90 seg).\n" +
                "Press militar en máquina o mancuernas (3x8-12, descanso: 90 seg).\n" +
                "Elevaciones laterales con mancuernas o en máquina (3x12-15, descanso: 60 seg).\n" +
                "Día 2: Bíceps, Tríceps, Espalda y Pecho\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo suave).\n" +
                "Ejercicios principales:\n" +
                "Pull-down en máquina (4x8-12, descanso: 90 seg).\n" +
                "Fondos en máquina o press de pecho en máquina (3x8-12, descanso: 90 seg).\n" +
                "Curl de bíceps en máquina o con mancuernas (3x10-12, descanso: 60 seg).\n" +
                "Extensión de tríceps en máquina o con cuerda (3x10-12, descanso: 60 seg).\n" +
                "Día 3: Espalda, Pecho y Hombros\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo suave).\n" +
                "Ejercicios principales:\n" +
                "Remo en máquina o polea baja (4x8-12, descanso: 90 seg).\n" +
                "Press de banca en máquina o mancuernas (4x8-12, descanso: 90 seg).\n" +
                "Elevaciones frontales con mancuernas o en máquina (3x12-15, descanso: 60 seg).\n" +
                "Face pull con cuerda en máquina (3x12-15, descanso: 60 seg).";
        return rutina;
    }

    private static String generarRutinaSubirDePesoConLesionInferior(Usuario usuario) {
        // Similar a la rutina anterior, pero con modificaciones para la lesión inferior
        String rutina = "Día 1: Tren Superior (Pecho, Espalda, Hombros) + Cardio Suave\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo suave).\n" +
                "Ejercicios principales:\n" +
                "Press de banca con barra o máquina (4x8-12, descanso: 90 seg).\n" +
                "Remo en máquina sentado o polea baja (4x8-12, descanso: 90 seg).\n" +
                "Press militar en máquina o mancuernas (3x8-12, descanso: 90 seg).\n" +
                "Elevaciones laterales con mancuernas o en máquina (3x12-15, descanso: 60 seg).\n" +
                "Cardio suave: Caminadora o elíptica (15-20 min, ritmo bajo).\n" +
                "Día 2: Tren Superior (Brazos, Pecho, Espalda) + Cardio\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Pull-down en máquina (4x8-12, descanso: 90 seg).\n" +
                "Fondos en máquina (3x8-12, descanso: 90 seg).\n" +
                "Curl de bíceps en máquina o mancuernas (3x10-12, descanso: 60 seg).\n" +
                "Extensión de tríceps en máquina o con cuerda (3x10-12, descanso: 60 seg).\n" +
                "Cardio: Bicicleta estática o caminadora (15-20 min, ritmo suave).\n" +
                "Día 3: Tren Superior (Espalda, Pecho, Hombros) + Cardio\n" +
                "Calentamiento: Caminadora o elíptica (10-15 min, ritmo moderado).\n" +
                "Ejercicios principales:\n" +
                "Remo en máquina (4x8-12, descanso: 90 seg).\n" +
                "Press de banca en máquina o mancuernas (4x8-12, descanso: 90 seg).\n" +
                "Elevaciones frontales con mancuernas o en máquina (3x12-15, descanso: 60 seg).\n" +
                "Face pull con cuerda en máquina (3x12-15, descanso: 60 seg).\n" +
                "Cardio suave: Caminadora o elíptica (15-20 min, ritmo moderado).";
        return rutina;
    }
}
