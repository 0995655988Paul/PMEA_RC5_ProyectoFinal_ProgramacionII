import java.util.ArrayList;
import java.util.HashMap;

public class Avance {

    // Estructura para guardar los avances de cada usuario
    private static HashMap<String, ArrayList<String>> registrosAvances = new HashMap<>();

    // Método para ingresar un avance
    public static void ingresarAvance(String cedula, String avance) {
        // Si el usuario no tiene avances registrados, creamos una nueva lista de avances
        if (!registrosAvances.containsKey(cedula)) {
            registrosAvances.put(cedula, new ArrayList<>());
        }
        // Agregamos el avance al usuario correspondiente
        registrosAvances.get(cedula).add(avance);
    }

    // Método para ver los avances previos de un usuario
    public static String verAvances(String cedula) {
        if (registrosAvances.containsKey(cedula)) {
            ArrayList<String> avances = registrosAvances.get(cedula);
            StringBuilder avancesText = new StringBuilder("Avances previos para el usuario con cédula " + cedula + ":\n");
            for (String avance : avances) {
                avancesText.append(avance).append("\n");
            }
            return avancesText.toString();
        } else {
            return "No se han registrado avances para el usuario con cédula " + cedula + ".";
        }
    }

    // Método para mostrar el menú de opciones para el usuario
    public static String mostrarMenu(String cedula) {
        return "Seleccione una opción:\n" +
                "1. Ingresar avance\n" +
                "2. Ver avances previos\n" +
                "Ingrese el número de opción (1 o 2):";
    }

    // Método para procesar la opción seleccionada por el usuario
    public static String procesarOpcion(String cedula, int opcion, String avance) {
        if (opcion == 1) {
            ingresarAvance(cedula, avance);
            return "Avance registrado exitosamente.";
        } else if (opcion == 2) {
            return verAvances(cedula);
        } else {
            return "Opción inválida. Por favor, elija una opción válida (1 o 2).";
        }
    }
}
