import javax.swing.*;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<String, Usuario> usuarios = new HashMap<>();
        boolean salir = false;

        while (!salir) {
            String[] opcionesMenu = {"Registrar Usuario", "Seleccionar Objetivo y Rutinas", "Seleccionar Plan Alimenticio", "Ingresar y Ver Avances", "Buscar Avances de Otro Usuario", "Salir"};
            String opcion = (String) JOptionPane.showInputDialog(null, "Seleccione una opción:", "Menú Principal", JOptionPane.PLAIN_MESSAGE, null, opcionesMenu, opcionesMenu[0]);

            if (opcion == null || opcion.equals("Salir")) {
                salir = true;
            } else if (opcion.equals("Registrar Usuario")) {
                registrarUsuario(usuarios);
            } else if (opcion.equals("Seleccionar Objetivo y Rutinas")) {
                Usuario usuario = obtenerUsuario(usuarios);
                if (usuario != null) {
                    seleccionarObjetivoYRutinas(usuario);
                }
            } else if (opcion.equals("Seleccionar Plan Alimenticio")) {
                Usuario usuario = obtenerUsuario(usuarios);
                if (usuario != null) {
                    seleccionarPlanAlimenticio(usuario);
                }
            } else if (opcion.equals("Ingresar y Ver Avances")) {
                Usuario usuario = obtenerUsuario(usuarios);
                if (usuario != null) {
                    ingresarYVerAvances(usuario);
                }
            } else if (opcion.equals("Buscar Avances de Otro Usuario")) {
                buscarAvances(usuarios);
            }
        }

        JOptionPane.showMessageDialog(null, "Gracias por usar el sistema. ¡Hasta luego!");
    }

    // Método para registrar un usuario
    private static void registrarUsuario(HashMap<String, Usuario> usuarios) {
        String nombre = JOptionPane.showInputDialog("Ingrese su nombre:");
        while (!validarNombreApellido(nombre)) {
            nombre = JOptionPane.showInputDialog("El nombre no puede contener números. Ingrese su nombre:");
        }

        String apellido = JOptionPane.showInputDialog("Ingrese su apellido:");
        while (!validarNombreApellido(apellido)) {
            apellido = JOptionPane.showInputDialog("El apellido no puede contener números. Ingrese su apellido:");
        }

        String cedula = JOptionPane.showInputDialog("Ingrese su número de cédula:");
        while (!validarCedula(cedula)) {
            cedula = JOptionPane.showInputDialog("La cédula debe tener 10 dígitos. Ingrese una cédula válida:");
        }

        if (nombre != null && apellido != null && cedula != null && !nombre.isEmpty() && !apellido.isEmpty() && !cedula.isEmpty()) {
            // Verificar si ya existe un usuario con la cédula
            if (usuarios.containsKey(cedula)) {
                JOptionPane.showMessageDialog(null, "Ya existe un usuario con esa cédula.");
                return;
            }

            Usuario usuario = new Usuario(nombre, apellido, cedula);
            usuarios.put(cedula, usuario);
            JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Registro cancelado o datos inválidos.");
        }
    }

    // Validación para nombre y apellido (que no contengan números)
    private static boolean validarNombreApellido(String texto) {
        return texto != null && texto.matches("[a-zA-ZáéíóúÁÉÍÓÚ ]+");
    }

    // Validación para cédula ecuatoriana (10 dígitos)
    private static boolean validarCedula(String cedula) {
        if (cedula == null || cedula.length() != 10) {
            return false;
        }

        // Algoritmo básico para validar la cédula
        int[] digitos = new int[10];
        for (int i = 0; i < 10; i++) {
            digitos[i] = Character.getNumericValue(cedula.charAt(i));
        }

        int suma = 0;
        for (int i = 0; i < 9; i++) {
            if (i % 2 == 0) {
                int valor = digitos[i] * 2;
                if (valor > 9) valor -= 9;
                suma += valor;
            } else {
                suma += digitos[i];
            }
        }

        int verificador = suma % 10 == 0 ? 0 : 10 - (suma % 10);
        return verificador == digitos[9];
    }

    // Método para obtener un usuario basado en su cédula
    private static Usuario obtenerUsuario(HashMap<String, Usuario> usuarios) {
        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del usuario:");
        Usuario usuario = usuarios.get(cedula);
        if (usuario == null) {
            JOptionPane.showMessageDialog(null, "No se encontró un usuario con esa cédula.");
        }
        return usuario;
    }

    // Método para seleccionar objetivo y rutinas
    private static void seleccionarObjetivoYRutinas(Usuario usuario) {
        String[] opcionesObjetivo = {"Bajar de peso", "Subir de peso y ganar masa muscular"};
        String objetivoSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione su objetivo:", "Objetivo", JOptionPane.PLAIN_MESSAGE, null, opcionesObjetivo, opcionesObjetivo[0]);

        if (objetivoSeleccionado != null) {
            if (objetivoSeleccionado.equals("Bajar de peso")) {
                usuario.setObjetivo(Usuario.Objetivo.BAJAR_DE_PESO);
            } else {
                usuario.setObjetivo(Usuario.Objetivo.SUBIR_DE_PESO_GANAR_MASA_MUSCULAR);
            }

            seleccionarLesion(usuario);
            seleccionarNivelEntrenamiento(usuario);

            // Generar y mostrar rutina
            String rutina = Rutina.generarRutina(usuario);
            JOptionPane.showMessageDialog(null, "Rutina generada:\n" + rutina);
        }
    }

    // Método para seleccionar lesión
    private static void seleccionarLesion(Usuario usuario) {
        String[] opcionesLesion = {"Sin lesiones", "Lesión en el tren superior", "Lesión en el tren inferior"};
        String lesionSeleccionada = (String) JOptionPane.showInputDialog(null, "¿Tiene alguna lesión?", "Lesión", JOptionPane.PLAIN_MESSAGE, null, opcionesLesion, opcionesLesion[0]);

        if (lesionSeleccionada != null) {
            switch (lesionSeleccionada) {
                case "Sin lesiones":
                    usuario.setLesion(Usuario.Lesion.SIN_LESION);
                    break;
                case "Lesión en el tren superior":
                    usuario.setLesion(Usuario.Lesion.SUPERIOR);
                    break;
                case "Lesión en el tren inferior":
                    usuario.setLesion(Usuario.Lesion.INFERIOR);
                    break;
            }
        }
    }

    // Método para seleccionar nivel de entrenamiento
    private static void seleccionarNivelEntrenamiento(Usuario usuario) {
        String[] opcionesNivel = {"Principiante", "Intermedio", "Avanzado"};
        String nivelSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione su nivel de entrenamiento:", "Nivel", JOptionPane.PLAIN_MESSAGE, null, opcionesNivel, opcionesNivel[0]);

        if (nivelSeleccionado != null) {
            switch (nivelSeleccionado) {
                case "Principiante":
                    usuario.setNivel(Usuario.NivelEntrenamiento.PRINCIPIANTE);
                    break;
                case "Intermedio":
                    usuario.setNivel(Usuario.NivelEntrenamiento.MEDIO);
                    break;
                case "Avanzado":
                    usuario.setNivel(Usuario.NivelEntrenamiento.AVANZADO);
                    break;
            }
        }
    }

    // Método para seleccionar plan alimenticio
    private static void seleccionarPlanAlimenticio(Usuario usuario) {
        // Aquí el usuario selecciona su preferencia alimenticia
        String[] opcionesPreferencia = {"Vegano", "Vegetariano", "Sin preferencia"};
        String preferenciaSeleccionada = (String) JOptionPane.showInputDialog(null, "Seleccione su preferencia alimenticia:", "Preferencia Alimenticia", JOptionPane.PLAIN_MESSAGE, null, opcionesPreferencia, opcionesPreferencia[0]);

        if (preferenciaSeleccionada != null) {
            switch (preferenciaSeleccionada) {
                case "Vegano":
                    usuario.setPreferenciaAlimenticia(Usuario.PreferenciaAlimenticia.VEGANO);
                    break;
                case "Vegetariano":
                    usuario.setPreferenciaAlimenticia(Usuario.PreferenciaAlimenticia.VEGETARIANO);
                    break;
                case "Sin preferencia":
                    usuario.setPreferenciaAlimenticia(Usuario.PreferenciaAlimenticia.SIN_PREFERENCIA);
                    break;
            }

            // Generar y mostrar plan alimenticio
            try {
                String planAlimenticio = PlanAlimenticio.generarPlanAlimenticio(usuario);
                JOptionPane.showMessageDialog(null, "Plan alimenticio:\n" + planAlimenticio);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al generar el plan alimenticio: " + e.getMessage());
            }
        }
    }

    // Método para ingresar y ver avances
    private static void ingresarYVerAvances(Usuario usuario) {
        String[] opcionesAvance = {"Ingresar avance", "Ver avances"};
        String opcionAvance = (String) JOptionPane.showInputDialog(null, "Seleccione una opción:", "Avances", JOptionPane.PLAIN_MESSAGE, null, opcionesAvance, opcionesAvance[0]);

        if (opcionAvance != null) {
            if (opcionAvance.equals("Ingresar avance")) {
                String avance = JOptionPane.showInputDialog("Ingrese su avance:");
                if (avance != null && !avance.isEmpty()) {
                    Avance.ingresarAvance(usuario.getCedula(), avance);
                    JOptionPane.showMessageDialog(null, "Avance registrado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Avance no válido.");
                }
            } else {
                String avances = Avance.verAvances(usuario.getCedula());
                JOptionPane.showMessageDialog(null, avances);
            }
        }
    }

    // Método para buscar avances de otro usuario
    private static void buscarAvances(HashMap<String, Usuario> usuarios) {
        String cedulaBusqueda = JOptionPane.showInputDialog("Ingrese la cédula del usuario a buscar:");

        // Verificar si existe un usuario con esa cédula
        Usuario usuario = usuarios.get(cedulaBusqueda);
        if (usuario != null) {
            // Mostrar avances del usuario
            String avances = Avance.verAvances(usuario.getCedula());
            JOptionPane.showMessageDialog(null, avances);
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró un usuario con esa cédula.");
        }
    }
}
