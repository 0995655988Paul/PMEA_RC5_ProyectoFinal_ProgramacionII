public class Usuario {

    // Atributos del usuario
    private String nombre;
    private String apellido;
    private String cedula;
    private Objetivo objetivo;
    private NivelEntrenamiento nivel;
    private Lesion lesion;
    private PreferenciaAlimenticia preferenciaAlimenticia;

    // Constructor para registrar nombre, apellido y cédula
    public Usuario(String nombre, String apellido, String cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.objetivo = null; // Inicialmente sin objetivo
        this.nivel = null; // Inicialmente sin nivel
        this.lesion = Lesion.SIN_LESION; // Por defecto, sin lesión
        this.preferenciaAlimenticia = PreferenciaAlimenticia.SIN_PREFERENCIA; // Por defecto, sin preferencia
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public Objetivo getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(Objetivo objetivo) {
        this.objetivo = objetivo;
    }

    public NivelEntrenamiento getNivel() {
        return nivel;
    }

    public void setNivel(NivelEntrenamiento nivel) {
        this.nivel = nivel;
    }

    public Lesion getLesion() {
        return lesion;
    }

    public void setLesion(Lesion lesion) {
        this.lesion = lesion;
    }

    public PreferenciaAlimenticia getPreferenciaAlimenticia() {
        return preferenciaAlimenticia;
    }

    public void setPreferenciaAlimenticia(PreferenciaAlimenticia preferenciaAlimenticia) {
        this.preferenciaAlimenticia = preferenciaAlimenticia;
    }

    // Método para obtener el nivel de entrenamiento
    public NivelEntrenamiento getNivelEntrenamiento() {
        return this.nivel;
    }

    // Enumeraciones
    public enum Objetivo {
        BAJAR_DE_PESO,
        SUBIR_DE_PESO_GANAR_MASA_MUSCULAR
    }

    public enum NivelEntrenamiento {
        PRINCIPIANTE,
        MEDIO,
        AVANZADO
    }

    public enum Lesion {
        SIN_LESION,
        SUPERIOR,
        INFERIOR
    }

    public enum PreferenciaAlimenticia {
        VEGANO,
        VEGETARIANO,
        SIN_PREFERENCIA
    }

    // Método para mostrar la información completa del usuario
    @Override
    public String toString() {
        return "Usuario{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", cedula='" + cedula + '\'' +
                ", objetivo=" + (objetivo != null ? objetivo : "No especificado") +
                ", nivel=" + (nivel != null ? nivel : "No especificado") +
                ", lesion=" + lesion +
                ", preferenciaAlimenticia=" + preferenciaAlimenticia +
                '}';
    }
}
