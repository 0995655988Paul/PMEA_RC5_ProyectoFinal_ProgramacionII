public class PlanAlimenticio {

    // Método para generar el plan alimenticio según el objetivo y preferencia del usuario
    public static String generarPlanAlimenticio(Usuario usuario) {
        String plan = "";

        // Verificar si el usuario ha seleccionado un objetivo y preferencia alimenticia
        if (usuario.getObjetivo() == null || usuario.getPreferenciaAlimenticia() == null) {
            return "Debe seleccionar un objetivo y una preferencia alimenticia para generar el plan.";
        }

        // Generación del plan alimenticio basado en el objetivo y preferencia alimenticia
        switch (usuario.getObjetivo()) {
            case BAJAR_DE_PESO:
                plan += "Plan alimenticio para bajar de peso:\n";
                plan += generarPlanBajarDePeso(usuario.getPreferenciaAlimenticia());
                break;

            case SUBIR_DE_PESO_GANAR_MASA_MUSCULAR:
                plan += "Plan alimenticio para subir de peso y ganar masa muscular:\n";
                plan += generarPlanSubirDePeso(usuario.getPreferenciaAlimenticia());
                break;

            default:
                plan += "Objetivo no válido.";
                break;
        }

        return plan;
    }

    // Método para generar el plan de bajar de peso según la preferencia alimenticia
    private static String generarPlanBajarDePeso(Usuario.PreferenciaAlimenticia preferencia) {
        String plan = "";
        switch (preferencia) {
            case VEGANO:
                plan = "Desayuno\n" +
                        "Avena con leche de almendra y frutas:\n" +
                        "1/2 taza de avena cocida, 1 taza de leche de almendra sin azúcar, 1/2 plátano en rodajas, 1 cucharada de semillas de chía, 1/4 taza de arándanos.\n" +
                        "Batido verde:\n" +
                        "1 taza de espinacas, 1 pepino, 1 manzana verde, 1/2 limón, 1/2 taza de agua de coco.\n" +
                        "Merienda de Media Mañana\n" +
                        "Yogur de soja con frutos rojos:\n" +
                        "1/2 taza de yogur de soja natural, 1/4 taza de frutos rojos, 1 cucharadita de semillas de linaza.\n" +
                        "Almuerzo\n" +
                        "Ensalada de quinoa y garbanzos:\n" +
                        "1/2 taza de quinoa cocida, 1/2 taza de garbanzos cocidos, espinacas, pepino, tomate, cebolla morada, aderezo de aceite de oliva y limón.\n" +
                        "Sopa de vegetales:\n" +
                        "1 taza de sopa de vegetales con caldo bajo en sodio (sin papas ni ingredientes calóricos).\n" +
                        "Merienda de Tarde\n" +
                        "Hummus con zanahorias y pepino:\n" +
                        "2 cucharadas de hummus, zanahorias y pepino en tiras.\n" +
                        "Cena\n" +
                        "Tofu salteado con brócoli y espárragos:\n" +
                        "100 g de tofu firme, 1 taza de brócoli, 1/2 taza de espárragos salteados con aceite de oliva y ajo.\n" +
                        "Ensalada mixta:\n" +
                        "Lechuga, pepino, tomate, zanahoria rallada, aderezo de vinagre de manzana y mostaza.\n" +
                        "Snack Nocturno\n" +
                        "Manzana con mantequilla de almendra:\n" +
                        "1 manzana, 1 cucharadita de mantequilla de almendra natural (sin azúcar añadido).";
                break;
            case VEGETARIANO:
                plan = "Desayuno\n" +
                        "Tostadas integrales con aguacate y huevo:\n" +
                        "1 rebanada de pan integral, 1/4 aguacate, 1 huevo revuelto con espinacas.\n" +
                        "Batido verde detox:\n" +
                        "1 taza de espinacas, 1 pepino, 1 manzana verde, 1/2 limón, 1/2 taza de agua.\n" +
                        "Merienda de Media Mañana\n" +
                        "Yogur griego natural con frutos rojos:\n" +
                        "1/2 taza de yogur griego bajo en grasa, 1/4 taza de frutos rojos.\n" +
                        "Almuerzo\n" +
                        "Ensalada de lentejas:\n" +
                        "1/2 taza de lentejas cocidas, tomate, pepino, cebolla morada, zanahoria rallada, aderezo de vinagre balsámico y aceite de oliva.\n" +
                        "Verduras asadas:\n" +
                        "1 taza de calabacín, pimientos y berenjenas asados con aceite de oliva y especias.\n" +
                        "Merienda de Tarde\n" +
                        "Rodajas de pepino con limón:\n" +
                        "Pepino cortado en rodajas con jugo de limón y sal marina.\n" +
                        "Cena\n" +
                        "Pasta integral con salsa de tomate y espinacas:\n" +
                        "1/2 taza de pasta integral cocida, 1/2 taza de salsa de tomate casera, 1 taza de espinacas salteadas.\n" +
                        "Ensalada de rúcula y aguacate:\n" +
                        "1 taza de rúcula, 1/4 de aguacate, tomate, cebolla roja, aderezo de limón y mostaza.\n" +
                        "Snack Nocturno\n" +
                        "Frutos secos:\n" +
                        "1 puñado pequeño de almendras o nueces.";
                break;
            case SIN_PREFERENCIA:
                plan = "Desayuno\n" +
                        "Tostadas integrales con aguacate y tomate:\n" +
                        "1 rebanada de pan integral, 1/4 aguacate, rodajas de tomate y albahaca fresca.\n" +
                        "Batido de proteínas:\n" +
                        "1 taza de leche de almendra sin azúcar, 1 cucharada de proteína de suero, 1/2 taza de frutos rojos, 1 cucharadita de linaza.\n" +
                        "Merienda de Media Mañana\n" +
                        "Frutos rojos con yogur griego:\n" +
                        "1/2 taza de yogur griego natural, 1/4 taza de fresas o arándanos, 1 cucharadita de semillas de chía.\n" +
                        "Almuerzo\n" +
                        "Pechuga de pollo a la parrilla con brócoli y quinoa:\n" +
                        "100 g de pechuga de pollo, 1/2 taza de brócoli al vapor, 1/2 taza de quinoa cocida.\n" +
                        "Ensalada de pepino y tomate:\n" +
                        "1/2 pepino, 1 tomate, cebolla morada, aderezo de vinagre de manzana y mostaza.\n" +
                        "Merienda de Tarde\n" +
                        "Rodajas de zanahoria con hummus:\n" +
                        "1 zanahoria cortada en tiras, 2 cucharadas de hummus.\n" +
                        "Cena\n" +
                        "Salmón al horno con espárragos:\n" +
                        "150 g de filete de salmón, 1 taza de espárragos al horno con aceite de oliva y ajo.\n" +
                        "Ensalada de espinacas y pepino:\n" +
                        "1 taza de espinacas, 1/2 pepino, 1 cucharada de semillas de calabaza, aderezo de aceite de oliva y limón.\n" +
                        "Snack Nocturno\n" +
                        "Manzana:\n" +
                        "1 manzana.";
                break;
            default:
                plan = "Preferencia alimenticia no válida.";
                break;
        }
        return plan;
    }

    // Método para generar el plan de subir de peso y ganar masa muscular según la preferencia alimenticia
    private static String generarPlanSubirDePeso(Usuario.PreferenciaAlimenticia preferencia) {
        String plan = "";
        switch (preferencia) {
            case VEGANO:
                plan = "Desayuno\n" +
                        "Avena con leche de almendra y frutos secos:\n" +
                        "1 taza de avena cocida con 1 taza de leche de almendra, 2 cucharadas de mantequilla de almendra, 1/4 taza de nueces picadas, 1 plátano en rodajas.\n" +
                        "Batido de proteínas vegano:\n" +
                        "1 taza de leche de coco, 1 cucharada de proteína vegetal, 1/2 taza de espinacas, 1/2 taza de frutos rojos, 1 cucharadita de aceite de linaza.\n" +
                        "Merienda de Media Mañana\n" +
                        "Tostadas de aguacate con hummus y semillas:\n" +
                        "2 rebanadas de pan integral, 1 aguacate, 2 cucharadas de hummus, 1 cucharadita de semillas de chía.\n" +
                        "Almuerzo\n" +
                        "Bowl de quinoa y tempeh:\n" +
                        "100 g de tempeh, 1/2 taza de quinoa cocida, 1/2 taza de vegetales asados (calabacín, pimientos, cebolla), 1 cucharada de aceite de oliva, salsa de soja.\n" +
                        "Ensalada de garbanzos:\n" +
                        "1/2 taza de garbanzos cocidos, tomate, pepino, cebolla, aderezo de aceite de oliva y limón.\n" +
                        "Merienda de Tarde\n" +
                        "Batido energético:\n" +
                        "1 taza de leche de almendra, 1 cucharada de crema de cacahuate, 1 cucharada de cacao en polvo, 1 plátano, 1 cucharada de proteína vegetal.\n" +
                        "Cena\n" +
                        "Tofu stir fry con arroz integral:\n" +
                        "150 g de tofu firme, 1/2 taza de arroz integral cocido, 1/2 taza de brócoli, zanahorias y pimientos salteados con aceite de oliva y salsa de soja.\n" +
                        "Ensalada verde:\n" +
                        "Lechuga, espinacas, tomate, pepino, aderezo de aceite de oliva y limón.\n" +
                        "Snack Nocturno\n" +
                        "Frutos secos y semillas:\n" +
                        "1 puñado de almendras, nueces, semillas de calabaza y girasol.";
                break;
            case VEGETARIANO:
                plan = "Desayuno\n" +
                        "Tostadas integrales con aguacate, huevo y queso:\n" +
                        "2 rebanadas de pan integral, 1 aguacate, 2 huevos revueltos, 1/4 taza de queso rallado (cheddar o mozzarella).\n" +
                        "Jugo verde:\n" +
                        "1 taza de espinacas, 1 pepino, 1 manzana verde, 1/2 limón, 1/2 taza de agua de coco.\n" +
                        "Merienda de Media Mañana\n" +
                        "Yogur griego con granola y miel:\n" +
                        "1 taza de yogur griego natural, 1/4 taza de granola, 1 cucharada de miel.\n" +
                        "Almuerzo\n" +
                        "Lentejas con arroz integral y espinacas:\n" +
                        "1 taza de lentejas cocidas, 1/2 taza de arroz integral, 1 taza de espinacas salteadas con ajo y aceite de oliva.\n" +
                        "Ensalada de garbanzos y aguacate:\n" +
                        "1/2 taza de garbanzos cocidos, tomate, pepino, cebolla, aguacate, aderezo de aceite de oliva y limón.\n" +
                        "Merienda de Tarde\n" +
                        "Batido de proteínas:\n" +
                        "1 taza de leche de almendra, 1 cucharada de proteína de suero, 1 plátano, 1 cucharadita de crema de cacahuate.\n" +
                        "Cena\n" +
                        "Pasta integral con albóndigas vegetarianas:\n" +
                        "1 taza de pasta integral cocida, 100 g de albóndigas vegetarianas (lentejas o soja texturizada), salsa de tomate casera, 1 cucharada de queso rallado.\n" +
                        "Ensalada mixta:\n" +
                        "Lechuga, zanahorias, pepino, aderezo de aceite de oliva y balsámico.\n" +
                        "Snack Nocturno\n" +
                        "Requesón con nueces:\n" +
                        "1/2 taza de requesón, 1 puñado de nueces.";
                break;
            case SIN_PREFERENCIA:
                plan = "Desayuno\n" +
                        "Tostadas de aguacate con huevo y queso:\n" +
                        "2 rebanadas de pan integral, 1 aguacate, 3 huevos revueltos, 1/4 taza de queso rallado (cheddar o mozzarella).\n" +
                        "Batido de avena y frutas:\n" +
                        "1 taza de leche entera, 1/2 taza de avena cocida, 1 plátano, 1 cucharadita de miel, 1 cucharada de crema de cacahuate.\n" +
                        "Merienda de Media Mañana\n" +
                        "Frutos secos con yogur griego:\n" +
                        "1 puñado de almendras, 1 taza de yogur griego natural.\n" +
                        "Almuerzo\n" +
                        "Pollo a la parrilla con arroz y brócoli:\n" +
                        "150 g de pechuga de pollo, 1/2 taza de arroz integral cocido, 1 taza de brócoli al vapor.\n" +
                        "Ensalada de quinoa y aguacate:\n" +
                        "1/2 taza de quinoa cocida, tomate, pepino, aguacate, cebolla morada, aderezo de aceite de oliva y limón.\n" +
                        "Merienda de Tarde\n" +
                        "Sandwich de atún con mayonesa:\n" +
                        "2 rebanadas de pan integral, 100 g de atún en agua o aceite, 1 cucharada de mayonesa, lechuga, tomate.\n" +
                        "Cena\n" +
                        "Filete de salmón con batatas asadas:\n" +
                        "150 g de filete de salmón, 1 batata asada con aceite de oliva, especias y ajo.\n" +
                        "Ensalada mixta:\n" +
                        "Lechuga, espinacas, zanahorias ralladas, pepino, tomate, aderezo de aceite de oliva y balsámico.\n" +
                        "Snack Nocturno\n" +
                        "Queso cottage con frutas:\n" +
                        "1/2 taza de queso cottage, 1/2 taza de frutas (piña, arándanos).";
                break;
            default:
                plan = "Preferencia alimenticia no válida.";
                break;
        }
        return plan;
    }
}
